//: Playground - noun: a place where people can play

import UIKit

// 1. Escribe una función que reciba como parámetro un número (entre 1 y 10) y
// muestre la tabla de multiplicar correspondiente
// IMPORTANTE: Usa el estatuto for de swift
// Llama a la función anterior con al menos 2 valores diferentes
func timesTable(number: Int) {
    for index in 1...10 {
        print(String(number) + " * " + String(index) + " = " + String(number * index))
    }
}

timesTable(2);

print("------------------------------------------")
// 2. Escribe un ciclo que muestre valores entre a y b avanzando de 2 en 2
for index in 80.stride(to: 135, by: 2) {
    print(index)
}

// Con while
var i = 80
while (i <= 135) {
    print(i)
    i += 2
}

print("------------------------------------------")
// 3. Escribe un estatuto switch que muestre valores numéricos de acuerdo a la siguiente tabla de claves
// A, F  - 25
// B, K  - 32
// D, E, G  - 40
var clave = "A"
switch (clave) {
    case "A", "F":
        print(25)
    case "B", "K":
        print(32)
    case "D", "E", "G":
        print(40)
    default:
        print(0)
}

print("------------------------------------------")
// 4. Crea un arreglo que contenga nombres de persona
// Luego haz un ciclo for para mostrar dichos nombres en la pantalla
var names: [String] = ["Bernardo", "Melissa", "Teno"]
for name in names {
    print(name)
}

// 5. Agrega un nombre al arreglo de nombres
names.append("Yolanda")

print("------------------------------------------")
// 6. Muestra el nombre que se encuentra en la posición (x)
// Usa un mensaje "En la posicion 2 se encuentra ...."
print("En la posicion 2 se encuentra \(names[1])")

print("------------------------------------------")
// 7. Declara un arreglo vacío de valores enteros
// Haz un ciclo para agregar al arreglo vacío algunos valores
// Muestra el contenido del arreglo usando un print con el nombre del arreglo
var numbers = [Int]()
for index in 1...5 {
    numbers.append(index)
}
print(numbers)

print("------------------------------------------")
// 8. Escribe una función que recibe un arreglo de números enteros y regresa como
// valor de retorno el valor mayor y el promedio de los valores del arreglo.
// Usa una tupla para regresar estos datos
// Crea un arreglo de números y llama a la función;
// después muestra los valores que regresó
func maxAndAverage(numbers: [Int]) -> (max: Int, average: Double) {
    if (numbers.count == 0) {
        return (-1111, -1111)
    } else {
        var sum = 0
        var max = numbers[0]
        for number in numbers {
            if number > max {
                max = number
            }
            sum += number
        }
        return (max, Double(sum)/Double(numbers.count))
    }
}

var functionNumbers: [Int] = [3,5,6,19,2,20,1]

print(maxAndAverage(functionNumbers));

print("------------------------------------------")
// 9. Escribe la clase Artículo con los atributos ident, descrip, precio
// que tenga un método de inicialización con valores default,
// un método de inicialización con parámetros y
// un método aumentaPrecio que reciba el porcentaje a aumentar como valor
// entero y regrese el nuevo precio sin modificar el precio del objeto
class Articulo {
    var ident: Int
    var descrip: String
    var precio: Double
    init() {
        ident = 0
        descrip = ""
        precio = 0.0
    }
    init(identificator: Int, description: String, price: Double) {
        ident = identificator
        descrip = description
        precio = price
    }
    func aumentaPrecio(percentage: Int) -> Double {
        return precio * (1 + Double(percentage)/100)
    }
    
    // Agregado para mostrar la informacion de la clase de forma sencilla
    func show() {
        print ("Identificador: \(ident)\tDescripcion: \(descrip)\tPrecio: \(precio)")
    }
}

// 10. Crea un objeto de tipo Artículo usando el constructor default y luego
// asigna un valor a cada uno de los atributos de ese objeto
var firstProduct = Articulo()
firstProduct.ident = 1
firstProduct.descrip = "Coca Cola Regular"
firstProduct.precio = 9.50

// 11. Crea un artículo más usando el constructor con parámetros
var secondProduct = Articulo(identificator: 2, description: "Hot dog", price: 38.00)

// 12. Crea un arreglo que contenga los artículos creados en los 2 puntos anteriores
// Usa un ciclo para mostrar (usando print) mensajes con los 3
// datos de cada uno de los artículos de la lista
var products: [Articulo] = [firstProduct, secondProduct]
for product in products {
    product.show()
}

// 13. Crea un artículo más usando cualquiera de los 2 constructores
// Agrega el artículo a la posición inicial del arreglo
var newFirstArticle = Articulo(identificator: 3, description: "Limonada Natural", price: 13.90)
products.insert(newFirstArticle, atIndex: 0)

// 14. Crea un artículo más usando cualquiera de los 2 constructores
// Agrega el artículo al final del arreglo de objetos
var lastArticle = Articulo(identificator: 4, description: "Hamburguesa", price: 48.20)
products.append(lastArticle)

print("------------------------------------------")
// 15. Muestra de nuevo el contenido del arreglo de objetos
for product in products {
    product.show()
}


